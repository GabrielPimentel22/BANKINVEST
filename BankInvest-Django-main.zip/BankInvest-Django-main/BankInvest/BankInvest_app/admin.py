from django.contrib import admin
from BankInvest_app.models import Cliente, Transacoes

# Register your models here.

admin.site.register(Cliente)    
admin.site.register(Transacoes)    