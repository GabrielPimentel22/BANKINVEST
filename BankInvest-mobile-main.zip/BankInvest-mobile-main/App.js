import { View } from "react-native";
import Rotas from "./routers";

export default function App() {
  return(
    <Rotas/>
  )
}