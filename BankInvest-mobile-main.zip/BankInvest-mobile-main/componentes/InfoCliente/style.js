import { StyleSheet } from "react-native";
import { DropShadowBase } from "react-native-drop-shadow";


const styles = StyleSheet.create({
    corpo: {
        flex: 1
    }

});

export default styles