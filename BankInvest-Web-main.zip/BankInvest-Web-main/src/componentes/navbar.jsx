export default function Navbar(){
    return(
        <nav style={{width:"100%", height:100, display: "flex", align_items: "center"}}>
            <h1>Bank Invest</h1>
        </nav>
    )
}